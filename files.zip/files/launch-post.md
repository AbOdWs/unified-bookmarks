# 🧠 بنيت دماغاً رقمياً شخصياً — مجاناً تقريباً

---

## النسخة العربية

بعد أشهر من التجربة والخطأ، بنيت نظاماً يحفظ كل شيء أتعلمه أو أحبه على الإنترنت — روابط، ملاحظات صوتية، صور — ويرتبها ذكياً في "دماغ" رقمي شخصي أستطيع سؤاله لاحقاً.

**المشكلة التي كانت تواجهني:**
كنت أحفظ روابط في المفضلة، وأرسل لنفسي رسائل في تيليغرام، وأضع ملاحظات في تطبيقات مختلفة — ثم لا أجد شيئاً عندما أحتاجه.

**الحل:**

بوت تيليغرام (وواتساب) يعمل على خادمي الخاص:

**الحفظ:**
- أرسل أي رابط → يحلله الذكاء الاصطناعي، يصنفه، يلخصه
- أرسل ملاحظة صوتية → يفرغها نصياً (عربي وإنجليزي)
- أرسل صورة → يصف محتواها ويحفظها
- أضيف ملاحظة شخصية مع الرابط: `https://... هذا للسفر`
- أضيف تذكير: `https://... /remind 2weeks`

**الاسترجاع:**
- "ما أفضل فندق حفظته في الصين؟"
- "أرني كل ما حفظته عن الذكاء الاصطناعي"
- `/list travel` — عرض كل روابط السفر

**التنظيم:**
- `/rules` — قواعد تصنيف مخصصة
- `/suggest` — الذكاء الاصطناعي يقترح إعادة تنظيم
- مزامنة تلقائية مع Obsidian

**المشاركة:**
- أدعو أفراد العائلة كضيوف بوصول محدود لفئات معينة
- مثالي للرحلات: "إليك كل ما حفظته عن الصين"

**التقنيات المستخدمة (كلها مجانية أو شبه مجانية):**
- n8n — أتمتة مفتوحة المصدر
- Groq — ذكاء اصطناعي مجاني (LLaMA 3.3 70B + Whisper)
- Firecrawl — استخراج محتوى الويب
- yt-dlp — استخراج معلومات الفيديو
- Obsidian — عرض المعرفة بصرياً
- Hostinger VPS — ~٣٠ ريال شهرياً

**التكلفة الإجمالية: ~٣٠ ريال شهرياً**

كل شيء يعمل على خادمك الخاص — بياناتك ملك لك.

المشروع مفتوح المصدر على GitHub 👇
[رابط المستودع]

إذا كنت تريد خادماً مشابهاً:
[رابط Hostinger مع خصم](https://www.hostinger.com?REFERRALCODE=GIQKABOD9A2H)

---

## English Version

After months of building and iterating, I created a self-hosted personal knowledge brain that captures everything I want to remember — links, voice notes, images — organizes it automatically with AI, and lets me query it later in natural language.

**The problem I had:**
I was bookmarking links, sending myself Telegram messages, dropping notes in random apps — then never finding anything when I needed it.

**The solution:**

A Telegram (and WhatsApp) bot running on my own VPS:

**Saving:**
- Send any URL → AI analyzes, categorizes, and summarizes it
- Send a voice note → Auto-transcription (Arabic & English)
- Send an image → AI vision description and save
- Add a personal note: `https://... this is for kitchen renovation`
- Add a reminder: `https://... /remind 2weeks`

**Retrieval:**
- "What's the best hotel I saved in China?"
- "Show me everything I saved about AI agents"
- `/list travel` — browse all travel links

**Organization:**
- `/rules` — set custom categorization rules
- `/suggest` — AI-powered reorganization suggestions
- Auto-sync with Obsidian as visual brain

**Sharing:**
- Invite family/friends as guests with access to specific categories
- Perfect for trips: "Here's everything I saved about China"

**Tech stack (mostly free):**
- n8n — open source workflow automation
- Groq — free AI (LLaMA 3.3 70B + Whisper transcription)
- Firecrawl — web content extraction
- yt-dlp — video metadata extraction
- Obsidian — visual knowledge browsing
- Hostinger VPS — ~$8/month

**Total cost: ~$8/month**

Everything runs on your own server — your data stays yours.

Open source on GitHub 👇
[repo link]

If you want a similar VPS setup:
[Hostinger with discount](https://www.hostinger.com?REFERRALCODE=GIQKABOD9A2H)

---

*Built by Abdullah Altamimi (@AbOd)*
